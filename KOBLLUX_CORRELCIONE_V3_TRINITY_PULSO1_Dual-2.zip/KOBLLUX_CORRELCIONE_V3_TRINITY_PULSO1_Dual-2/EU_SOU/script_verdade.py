# [A_VERDADE] Resposta simbólica
