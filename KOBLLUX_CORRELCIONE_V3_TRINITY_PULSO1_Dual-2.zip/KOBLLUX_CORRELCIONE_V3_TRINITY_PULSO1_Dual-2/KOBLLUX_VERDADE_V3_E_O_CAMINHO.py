# Script principal com lógica trinitária integrada
