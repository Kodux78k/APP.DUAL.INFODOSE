# [A_VIDA] Fluxo final e reinício
