# [EU_SOU] Raiz da Identidade
