# [O_CAMINHO] Escuta simbólica
